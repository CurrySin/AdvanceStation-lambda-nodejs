function Utils() {}
// class methods
Utils.prototype.test = function() {
    return 'utils testing string';
};
// export the class
module.exports = Utils;